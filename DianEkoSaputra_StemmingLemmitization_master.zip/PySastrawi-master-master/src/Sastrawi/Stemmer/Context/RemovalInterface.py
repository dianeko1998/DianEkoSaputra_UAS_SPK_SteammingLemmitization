class RemovalInterface(object):
    """description of class"""

    def get_visitor(self):
        pass

    def get_subject(self):
        pass

    def get_result(self):
        pass

    def get_removed_part(self):
        pass

    def get_affix_type(self):
        pass





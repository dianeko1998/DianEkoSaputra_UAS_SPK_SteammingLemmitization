class CacheInterface(object):
    """description of class"""

    def has(self, key):
        pass

    def set(self, key, value):
        pass

    def get(self, key):
        pass


